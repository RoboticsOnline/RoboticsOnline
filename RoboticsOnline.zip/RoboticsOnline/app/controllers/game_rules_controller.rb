class GameRulesController < ApplicationController
  def index
  end
end
