class RenameStrenghtToStrengthInStats < ActiveRecord::Migration
  def change
	rename_column :stats, :strenght, :strength
  end
end
