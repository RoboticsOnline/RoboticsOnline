require 'test_helper'

class TicketHelperTest < ActionView::TestCase
end
