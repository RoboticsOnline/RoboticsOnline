module GameRulesHelper
end
