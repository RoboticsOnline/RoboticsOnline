module RanklistHelper
end
