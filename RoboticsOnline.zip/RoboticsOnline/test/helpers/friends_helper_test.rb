require 'test_helper'

class FriendsHelperTest < ActionView::TestCase
end
