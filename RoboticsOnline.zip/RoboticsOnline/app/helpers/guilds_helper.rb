module GuildsHelper
end
