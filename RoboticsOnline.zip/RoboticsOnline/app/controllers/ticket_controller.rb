class TicketController < ApplicationController
end
