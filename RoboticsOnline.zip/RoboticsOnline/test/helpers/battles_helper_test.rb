require 'test_helper'

class BattlesHelperTest < ActionView::TestCase
end
