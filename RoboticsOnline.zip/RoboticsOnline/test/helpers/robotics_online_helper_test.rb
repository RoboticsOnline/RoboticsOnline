require 'test_helper'

class RoboticsOnlineHelperTest < ActionView::TestCase
end
