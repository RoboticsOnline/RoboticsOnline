class Message < ActiveRecord::Base
  # Setup accessible (or protected) attributes for your model
  attr_accessible :from_id, :to_id, :content, :unread, :time_sent
  # attr_accessible :title, :body

  belongs_to :user
end
