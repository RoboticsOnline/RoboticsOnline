require 'test_helper'

class RanklistHelperTest < ActionView::TestCase
end
