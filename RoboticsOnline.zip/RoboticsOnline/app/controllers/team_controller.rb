class TeamController < ApplicationController
  def index
  end
end
