class FriendsController < ApplicationController
  def index
  end
end
