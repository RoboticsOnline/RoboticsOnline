# Be sure to restart your server when you modify this file.

RoboticsOnline::Application.config.session_store :cookie_store, key: '_RoboticsOnline_session'
