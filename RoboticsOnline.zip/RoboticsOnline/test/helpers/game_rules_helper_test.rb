require 'test_helper'

class GameRulesHelperTest < ActionView::TestCase
end
