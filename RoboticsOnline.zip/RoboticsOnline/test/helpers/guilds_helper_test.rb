require 'test_helper'

class GuildsHelperTest < ActionView::TestCase
end
