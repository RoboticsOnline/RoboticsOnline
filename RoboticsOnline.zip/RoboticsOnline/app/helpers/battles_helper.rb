module BattlesHelper
end
