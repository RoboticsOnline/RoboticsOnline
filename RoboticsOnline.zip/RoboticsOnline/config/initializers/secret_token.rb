# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
RoboticsOnline::Application.config.secret_key_base = '01e8ea8b823e740786f4ee4237e5d7346f43a3b03c057ac3ee67d280bb4a3e64595920ec34cb15bcf5a51df8ce1abded75605fe82a47a00fb2ccf9055084a5af'
