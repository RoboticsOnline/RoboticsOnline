class GuildsController < ApplicationController
  def index
  end
end
