require 'test_helper'

class TeamHelperTest < ActionView::TestCase
end
